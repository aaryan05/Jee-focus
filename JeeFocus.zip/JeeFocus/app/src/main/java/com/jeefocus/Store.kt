package com.jeefocus

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Goal(
    val id: Long,
    val title: String,
    val subject: String,
    val start: Long,
    val end: Long,
    val done: Boolean
)

fun Context.dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

object Store {
    private fun p(c: Context) = c.getSharedPreferences("jf", Context.MODE_PRIVATE)

    fun goals(c: Context): List<Goal> {
        val a = JSONArray(p(c).getString("goals", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Goal(o.getLong("id"), o.getString("title"), o.getString("subject"),
                o.getLong("start"), o.getLong("end"), o.getBoolean("done"))
        }
    }

    fun saveGoals(c: Context, list: List<Goal>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("title", it.title).put("subject", it.subject)
                .put("start", it.start).put("end", it.end).put("done", it.done))
        }
        p(c).edit().putString("goals", a.toString()).apply()
    }

    fun add(c: Context, g: Goal) = saveGoals(c, goals(c) + g)
    fun remove(c: Context, id: Long) = saveGoals(c, goals(c).filter { it.id != id })
    fun find(c: Context, id: Long): Goal? = goals(c).firstOrNull { it.id == id }
    fun setDone(c: Context, id: Long) =
        saveGoals(c, goals(c).map { if (it.id == id) it.copy(done = true) else it })

    fun activeGoal(c: Context): Goal? {
        val now = System.currentTimeMillis()
        return goals(c).firstOrNull { !it.done && now >= it.start && now < it.end }
    }

    fun blocked(c: Context): Set<String> =
        p(c).getStringSet("blocked", emptySet())!!.toSet()

    fun setBlocked(c: Context, s: Set<String>) =
        p(c).edit().putStringSet("blocked", HashSet(s)).apply()

    fun fmt(t: Long): String =
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(t))

    fun hm(t: Long): String =
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(t))
}
