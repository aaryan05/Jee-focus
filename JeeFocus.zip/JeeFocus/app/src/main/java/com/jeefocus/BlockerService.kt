package com.jeefocus

import android.app.PendingIntent
import android.app.Notification
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class BlockerService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var last = System.currentTimeMillis() - 600000
    private var cur: String? = null

    private val tick = object : Runnable {
        override fun run() {
            try { check() } catch (_: Exception) {}
            h.postDelayed(this, 700)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Notifier.channels(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "service")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Focus protection is on")
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        h.post(tick)
    }

    private fun check() {
        val now = System.currentTimeMillis()
        val um = getSystemService(UsageStatsManager::class.java)
        val ev = um.queryEvents(last - 1000, now)
        last = now
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) cur = e.packageName
        }
        if (Store.activeGoal(this) == null) return
        val pkg = cur ?: return
        if (pkg in Store.blocked(this)) {
            startActivity(Intent(this, BlockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            cur = packageName
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        h.removeCallbacks(tick)
        super.onDestroy()
    }
}
