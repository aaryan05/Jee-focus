package com.jeefocus

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object C {
    val BG = Color.parseColor("#0A0A12")
    val BG2 = Color.parseColor("#17132B")
    val SHEET = Color.parseColor("#1B1833")
    val CARD = Color.parseColor("#14FFFFFF")
    val CARD_STROKE = Color.parseColor("#1CFFFFFF")
    val CHIP = Color.parseColor("#1FFFFFFF")
    val TEXT = Color.parseColor("#F4F2FF")
    val SUB = Color.parseColor("#9C98B8")
    val ACCENT = Color.parseColor("#7C5CFF")
    val ACCENT2 = Color.parseColor("#B69CFF")
    val AMBER = Color.parseColor("#FFC145")
    val GREEN = Color.parseColor("#3DDC97")
    val RED = Color.parseColor("#FF6B6B")
    val BLUE = Color.parseColor("#5AA9FF")
    val PURPLE = Color.parseColor("#C4A7FF")
}

fun tint(c: Int): Int = (c and 0x00FFFFFF) or 0x2E000000

fun subjectColor(s: String): Int = when (s) {
    "Physics" -> C.BLUE
    "Chemistry" -> C.GREEN
    "Maths" -> C.AMBER
    else -> C.PURPLE
}

fun Activity.styleBars() {
    window.statusBarColor = C.BG
    window.navigationBarColor = C.BG2
}

fun bgGradient(): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.BG, C.BG2))

fun medium(): Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
fun light(): Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)

fun Context.shape(color: Int, r: Int = 16, stroke: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(r).toFloat()
    if (stroke != 0) g.setStroke(dp(1), stroke)
    return g
}

fun Context.glass(r: Int = 22): GradientDrawable = shape(C.CARD, r, C.CARD_STROKE)

fun Context.gradBg(r: Int): GradientDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#8A6BFF"), Color.parseColor("#5B6CFF")))
    g.cornerRadius = dp(r).toFloat()
    return g
}

fun Context.label(t: String, size: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        typeface = if (bold) medium() else Typeface.DEFAULT
    }

fun Context.caps(t: String, color: Int = C.SUB): TextView = label(t.uppercase(), 11f, color, true).apply {
    letterSpacing = 0.14f
}

fun Context.primary(t: String, onClick: () -> Unit): TextView = TextView(this).apply {
    text = t
    textSize = 16f
    gravity = Gravity.CENTER
    setTextColor(Color.WHITE)
    typeface = medium()
    setPadding(dp(20), dp(16), dp(20), dp(16))
    background = gradBg(18)
    isClickable = true
    setOnClickListener { onClick() }
}

fun Context.btn(t: String, bg: Int, fg: Int = Color.WHITE, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = t
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(fg)
        typeface = medium()
        setPadding(dp(16), dp(13), dp(16), dp(13))
        background = shape(bg, 16)
        isClickable = true
        setOnClickListener { onClick() }
    }

fun LinearLayout.add(v: View, top: Int = 0): View {
    addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(top) })
    return v
}

fun LinearLayout.addW(v: View, left: Int = 0) {
    addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = context.dp(left) })
}

fun leftText(ms: Long): String {
    val m = (ms / 60000).toInt().coerceAtLeast(0)
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "$m min"
}

fun dayIndex(t: Long): Long = (t + TimeZone.getDefault().getOffset(t)) / 86400000L

fun whenText(t: Long): String {
    val d = dayIndex(t) - dayIndex(System.currentTimeMillis())
    val day = when (d) {
        0L -> "Today"
        1L -> "Tomorrow"
        -1L -> "Yesterday"
        else -> SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t))
    }
    return "$day, ${Store.hm(t)}"
}

class RingView(c: Context) : View(c) {
    var progress = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var caption = ""
    var big = ""
    var sub = ""

    private val d = c.resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#1FFFFFFF")
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2
        val cy = h / 2
        val sw = 14 * d
        track.strokeWidth = sw
        arc.strokeWidth = sw
        val r = minOf(w, h) / 2 - sw
        cv.drawCircle(cx, cy, r, track)
        if (progress > 0.001f) {
            arc.shader = SweepGradient(cx, cy, intArrayOf(C.ACCENT, C.ACCENT2, C.ACCENT), null)
            cv.save()
            cv.rotate(-90f, cx, cy)
            cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 0f, 360f * progress, false, arc)
            cv.restore()
        }
        tp.typeface = medium()
        tp.textSize = 11 * d
        tp.letterSpacing = 0.16f
        tp.color = C.SUB
        cv.drawText(caption.uppercase(), cx, cy - 42 * d, tp)

        tp.letterSpacing = 0f
        tp.typeface = light()
        tp.textSize = (if (big.length > 5) 38 else 52) * d
        tp.color = C.TEXT
        cv.drawText(big, cx, cy + 14 * d, tp)

        tp.typeface = Typeface.DEFAULT
        tp.textSize = 13 * d
        tp.color = C.SUB
        cv.drawText(sub, cx, cy + 44 * d, tp)
    }
}
