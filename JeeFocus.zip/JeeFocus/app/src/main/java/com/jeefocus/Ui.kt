package com.jeefocus

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val BG = Color.parseColor("#0E0F13")
    val CARD = Color.parseColor("#1A1C23")
    val TEXT = Color.parseColor("#FFFFFF")
    val SUB = Color.parseColor("#9AA0AE")
    val ACCENT = Color.parseColor("#6C63FF")
    val GREEN = Color.parseColor("#34D399")
    val ORANGE = Color.parseColor("#FFA726")
    val RED = Color.parseColor("#FF5C5C")
    val BLUE = Color.parseColor("#4DA3FF")
    val AMBER = Color.parseColor("#FBBF24")
    val PURPLE = Color.parseColor("#A78BFA")
}

fun tint(c: Int): Int = (c and 0x00FFFFFF) or 0x30000000

fun subjectColor(s: String): Int = when (s) {
    "Physics" -> C.BLUE
    "Chemistry" -> C.GREEN
    "Maths" -> C.AMBER
    else -> C.PURPLE
}

fun Activity.styleBars() {
    window.statusBarColor = C.BG
    window.navigationBarColor = C.BG
}

fun Context.shape(color: Int, r: Int = 16, stroke: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(r).toFloat()
    if (stroke != 0) g.setStroke(dp(1), stroke)
    return g
}

fun Context.label(t: String, size: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

fun Context.pill(t: String, bg: Int, fg: Int): TextView = TextView(this).apply {
    text = t
    textSize = 11f
    setTextColor(fg)
    setTypeface(typeface, Typeface.BOLD)
    setPadding(dp(10), dp(4), dp(10), dp(4))
    background = shape(bg, 50)
}

fun Context.btn(t: String, bg: Int, fg: Int = Color.WHITE, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = t
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(fg)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        background = shape(bg, 14)
        isClickable = true
        setOnClickListener { onClick() }
    }

fun Context.card(color: Int = C.CARD, stroke: Int = 0): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(16), dp(16), dp(16), dp(16))
    background = shape(color, 20, stroke)
}

fun LinearLayout.add(v: View, top: Int = 0): View {
    addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(top) })
    return v
}

fun LinearLayout.addW(v: View, left: Int = 0) {
    addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = context.dp(left) })
}

fun leftText(ms: Long): String {
    val m = (ms / 60000).toInt().coerceAtLeast(0)
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m} min"
}
