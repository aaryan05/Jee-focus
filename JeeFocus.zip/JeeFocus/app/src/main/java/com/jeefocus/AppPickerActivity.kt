package com.jeefocus

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class AppPickerActivity : Activity() {
    private class AppItem(val pkg: String, val name: String, val icon: Drawable?)

    private lateinit var holder: LinearLayout
    private lateinit var count: TextView
    private val items = ArrayList<AppItem>()
    private val sel = HashSet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars()
        sel.addAll(Store.blocked(this))
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != packageName }
            .forEach { p ->
                val name = try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (_: Exception) { p }
                val ic = try { pm.getApplicationIcon(p) } catch (_: Exception) { null }
                items.add(AppItem(p, name, ic))
            }
        items.sortWith(compareBy({ it.pkg !in sel }, { it.name.lowercase() }))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = bgGradient()
        root.setPadding(dp(20), dp(44), dp(20), 0)
        root.add(label("Block apps", 28f, C.TEXT, true))
        count = label("", 14f, C.SUB)
        root.add(count, 2)

        val search = EditText(this)
        search.hint = "Search apps"
        search.setHintTextColor(Color.parseColor("#66FFFFFF"))
        search.setTextColor(C.TEXT)
        search.textSize = 15f
        search.setSingleLine(true)
        search.setPadding(dp(16), dp(13), dp(16), dp(13))
        search.background = glass(16)
        root.add(search, 18)

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        holder.setPadding(0, 0, 0, dp(28))
        sv.addView(holder)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(12) })
        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { render(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        render("")
    }

    private fun updateCount() {
        count.text = "${sel.size} selected  •  locked during your goals"
    }

    private fun render(query: String) {
        holder.removeAllViews()
        updateCount()
        val q = query.trim().lowercase()
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        for (item in items.filter { x -> q.isEmpty() || x.name.lowercase().contains(q) }) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            row.background = glass(18)
            val iv = ImageView(this)
            iv.setImageDrawable(item.icon)
            row.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
            row.addView(label(item.name, 15f, C.TEXT),
                LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
            val sw = Switch(this)
            sw.trackTintList = ColorStateList(states, intArrayOf(C.ACCENT, Color.parseColor("#44FFFFFF")))
            sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.parseColor("#BBBBCC")))
            sw.isChecked = item.pkg in sel
            sw.setOnCheckedChangeListener { _, on ->
                if (on) sel.add(item.pkg) else sel.remove(item.pkg)
                Store.setBlocked(this, sel)
                updateCount()
            }
            row.setOnClickListener { sw.toggle() }
            row.addView(sw)
            holder.add(row, 8)
        }
    }
}
