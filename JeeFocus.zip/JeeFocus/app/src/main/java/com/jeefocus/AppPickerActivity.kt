package com.jeefocus

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch

class AppPickerActivity : Activity() {
    private class AppItem(val pkg: String, val name: String, val icon: Drawable?)

    private lateinit var holder: LinearLayout
    private lateinit var count: android.widget.TextView
    private val items = ArrayList<AppItem>()
    private val sel = HashSet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars()
        sel.addAll(Store.blocked(this))
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != packageName }
            .forEach { p ->
                val name = try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (_: Exception) { p }
                val ic = try { pm.getApplicationIcon(p) } catch (_: Exception) { null }
                items.add(AppItem(p, name, ic))
            }
        items.sortBy { it.name.lowercase() }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(18), dp(48), dp(18), 0)
        root.add(label("Block apps", 28f, C.TEXT, true))
        count = label("", 14f, C.SUB)
        root.add(count, 2)

        val search = EditText(this)
        search.hint = "Search apps"
        search.setHintTextColor(C.SUB)
        search.setTextColor(C.TEXT)
        search.textSize = 15f
        search.setSingleLine(true)
        search.setPadding(dp(14), dp(12), dp(14), dp(12))
        search.background = shape(C.CARD, 14)
        root.add(search, 16)

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        holder.setPadding(0, 0, 0, dp(24))
        sv.addView(holder)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(12) })
        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { render(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        render("")
    }

    private fun render(query: String) {
        holder.removeAllViews()
        count.text = "${sel.size} selected. These get locked during goals."
        val q = query.trim().lowercase()
        for (it in items.filter { x -> q.isEmpty() || x.name.lowercase().contains(q) }) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            row.background = shape(C.CARD, 16)
            val iv = ImageView(this)
            iv.setImageDrawable(it.icon)
            row.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
            val name = label(it.name, 15f, C.TEXT)
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
            val sw = Switch(this)
            sw.isChecked = it.pkg in sel
            sw.setOnCheckedChangeListener { _, on ->
                if (on) sel.add(it.pkg) else sel.remove(it.pkg)
                Store.setBlocked(this, sel)
                count.text = "${sel.size} selected. These get locked during goals."
            }
            row.setOnClickListener { sw.toggle() }
            row.addView(sw)
            holder.add(row, 8)
        }
    }
}
