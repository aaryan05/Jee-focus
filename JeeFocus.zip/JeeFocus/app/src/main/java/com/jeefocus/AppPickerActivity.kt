package com.jeefocus

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class AppPickerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(24))
        }
        sv.addView(l)
        setContentView(sv)

        l.addView(TextView(this).apply {
            text = "Select apps to lock during goals"
            textSize = 20f
            setPadding(0, 0, 0, dp(12))
        })

        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != packageName }
            .map { it to pm.getApplicationLabel(pm.getApplicationInfo(it, 0)).toString() }
            .sortedBy { it.second.lowercase() }

        val sel = Store.blocked(this).toMutableSet()
        for ((pkg, label) in apps) {
            val cb = CheckBox(this)
            cb.text = label
            cb.isChecked = pkg in sel
            try {
                val ic = pm.getApplicationIcon(pkg)
                ic.setBounds(0, 0, dp(40), dp(40))
                cb.setCompoundDrawables(ic, null, null, null)
                cb.compoundDrawablePadding = dp(12)
            } catch (_: Exception) {}
            cb.setOnCheckedChangeListener { _, checked ->
                if (checked) sel.add(pkg) else sel.remove(pkg)
                Store.setBlocked(this, sel)
            }
            l.addView(cb)
        }
    }
}
