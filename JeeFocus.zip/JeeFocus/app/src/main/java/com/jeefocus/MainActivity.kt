package com.jeefocus

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Perm {
    fun usage(c: Context): Boolean {
        val ops = c.getSystemService(AppOpsManager::class.java)
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }
    fun overlay(c: Context) = Settings.canDrawOverlays(c)
    fun exact(c: Context) =
        Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    fun notif(c: Context) =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 30000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars()
        Notifier.channels(this)
        val frame = FrameLayout(this)
        frame.setBackgroundColor(C.BG)
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(48), dp(18), dp(120))
        }
        sv.addView(list)
        frame.addView(sv, FrameLayout.LayoutParams(-1, -1))
        val fab = btn("+  New goal", C.ACCENT) { addDialog() }
        fab.textSize = 15f
        fab.setPadding(dp(26), dp(16), dp(26), dp(16))
        fab.background = shape(C.ACCENT, 50)
        frame.addView(fab, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END)
            .apply { setMargins(0, 0, dp(20), dp(28)) })
        setContentView(frame)
        if (!Perm.notif(this)) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        try { startForegroundService(Intent(this, BlockerService::class.java)) } catch (_: Exception) {}
        h.removeCallbacks(tick)
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }

    private fun pkgUri() = Uri.parse("package:$packageName")

    private fun refresh() {
        list.removeAllViews()
        val now = System.currentTimeMillis()
        val all = Store.goals(this)

        list.add(label("JEE Focus", 30f, C.TEXT, true))
        list.add(label(SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(Date(now)), 14f, C.SUB), 2)

        val act = Store.activeGoal(this)
        val hero = card(if (act != null) C.ACCENT else C.CARD)
        if (act != null) {
            hero.add(label("FOCUS MODE ON", 11f, Color.parseColor("#D9D6FF"), true))
            hero.add(label(act.title, 22f, Color.WHITE, true), 6)
            hero.add(label("Apps locked  •  ${leftText(act.end - now)} left (till ${Store.hm(act.end)})", 14f, Color.parseColor("#E8E6FF")), 4)
            hero.add(btn("Mark done", Color.WHITE, C.ACCENT) { Scheduler.complete(this, act.id); refresh() }, 14)
        } else {
            val next = all.filter { !it.done && it.start > now }.minByOrNull { it.start }
            hero.add(label("NO ACTIVE GOAL", 11f, C.SUB, true))
            hero.add(label("Your apps are free", 20f, C.TEXT, true), 6)
            hero.add(label(
                if (next != null) "Next: ${next.title} at ${Store.hm(next.start)}" else "Add a goal to start focusing.",
                14f, C.SUB), 4)
        }
        list.add(hero, 20)

        val missing = ArrayList<Pair<String, () -> Unit>>()
        if (!Perm.usage(this)) missing.add("Allow Usage Access" to {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        if (!Perm.overlay(this)) missing.add("Allow Display Over Other Apps" to {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri())) })
        if (!Perm.exact(this)) missing.add("Allow Exact Alarms" to {
            if (Build.VERSION.SDK_INT >= 31)
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri())) })
        if (!Perm.notif(this)) missing.add("Allow Notifications" to {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) })
        if (missing.isNotEmpty()) {
            val pc = card(C.CARD, C.ORANGE)
            pc.add(label("Finish setup", 16f, C.ORANGE, true))
            pc.add(label("Locking and alerts won't work until these are allowed.", 13f, C.SUB), 2)
            for ((t, f) in missing) pc.add(btn(t, tint(C.ORANGE), C.ORANGE) { f() }, 10)
            list.add(pc, 14)
        }

        val sod = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val today = all.filter { it.start >= sod && it.start < sod + 86400000L }
        val stats = LinearLayout(this)
        val s1 = card()
        s1.add(label("${today.count { it.done }}/${today.size}", 24f, C.TEXT, true))
        s1.add(label("Done today", 12f, C.SUB), 2)
        val s2 = card()
        s2.add(label("${Store.blocked(this).size}", 24f, C.TEXT, true))
        s2.add(label("Apps blocked  >", 12f, C.SUB), 2)
        s2.setOnClickListener { startActivity(Intent(this, AppPickerActivity::class.java)) }
        stats.addW(s1)
        stats.addW(s2, 12)
        list.add(stats, 14)

        list.add(label("Goals", 18f, C.TEXT, true), 26)
        if (all.isEmpty()) {
            list.add(label("No goals yet. Tap New goal to add your first one.", 14f, C.SUB), 8)
        }
        val sorted = all.sortedWith(compareBy({ it.done }, { it.start }))
        for (g in sorted) {
            val col = subjectColor(g.subject)
            val (stText, stCol) = when {
                g.done -> "DONE" to C.GREEN
                now < g.start -> "UPCOMING" to C.BLUE
                now < g.end -> "LOCKED" to C.ORANGE
                else -> "OVERDUE" to C.RED
            }
            val gc = card()
            val top = LinearLayout(this)
            top.gravity = Gravity.CENTER_VERTICAL
            top.addW(pill(g.subject, tint(col), col).also { it.gravity = Gravity.START })
            top.addView(pill(stText, tint(stCol), stCol))
            gc.add(top)
            gc.add(label(g.title, 17f, if (g.done) C.SUB else C.TEXT, true), 10)
            gc.add(label("${Store.fmt(g.start)}  →  ${Store.hm(g.end)}", 13f, C.SUB), 4)
            val row = LinearLayout(this)
            if (!g.done) row.addW(btn("Done", tint(C.GREEN), C.GREEN) { Scheduler.complete(this, g.id); refresh() })
            row.addW(btn("Delete", Color.parseColor("#262932"), C.SUB) { Scheduler.delete(this, g.id); refresh() }, if (g.done) 0 else 10)
            gc.add(row, 12)
            list.add(gc, 10)
        }
    }

    private fun pick(cb: (Long) -> Unit) {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, hh, mm ->
                val r = Calendar.getInstance()
                r.set(y, m, d, hh, mm, 0)
                r.set(Calendar.MILLISECOND, 0)
                cb(r.timeInMillis)
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun addDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(20), dp(20), dp(20))
        box.background = shape(C.CARD, 24)

        box.add(label("New goal", 20f, C.TEXT, true))

        val title = EditText(this)
        title.hint = "e.g. Rotational motion 30 Qs"
        title.setHintTextColor(C.SUB)
        title.setTextColor(C.TEXT)
        title.textSize = 15f
        title.setSingleLine(true)
        title.setPadding(dp(14), dp(12), dp(14), dp(12))
        title.background = shape(C.BG, 12)
        box.add(title, 14)

        box.add(label("Subject", 12f, C.SUB), 14)
        val subjects = listOf("Physics", "Chemistry", "Maths", "Other")
        var sel = 0
        val pills = subjects.map { pill(it, 0, 0) }
        fun paint() {
            pills.forEachIndexed { i, p ->
                val col = subjectColor(subjects[i])
                if (i == sel) { p.background = shape(col, 50); p.setTextColor(Color.BLACK) }
                else { p.background = shape(tint(col), 50); p.setTextColor(col) }
            }
        }
        val prow = LinearLayout(this)
        pills.forEachIndexed { i, p ->
            p.setOnClickListener { sel = i; paint() }
            prow.addView(p, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        paint()
        box.add(prow, 6)

        var s = System.currentTimeMillis() / 60000 * 60000
        var e = s + 3600000L
        val sBox = label("", 13f, C.TEXT)
        val eBox = label("", 13f, C.TEXT)
        for (b in listOf(sBox, eBox)) {
            b.setPadding(dp(14), dp(12), dp(14), dp(12))
            b.background = shape(C.BG, 12)
        }
        fun times() {
            sBox.text = "Start\n${Store.fmt(s)}"
            eBox.text = "End\n${Store.fmt(e)}"
        }
        times()
        sBox.setOnClickListener { pick { s = it; if (e <= s) e = s + 3600000L; times() } }
        eBox.setOnClickListener { pick { e = it; times() } }
        val trow = LinearLayout(this)
        trow.addW(sBox)
        trow.addW(eBox, 10)
        box.add(trow, 16)

        box.add(label("Quick duration", 12f, C.SUB), 14)
        val drow = LinearLayout(this)
        listOf("30 min" to 30, "1 hr" to 60, "2 hr" to 120, "3 hr" to 180).forEachIndexed { i, (t, m) ->
            val p = pill(t, Color.parseColor("#262932"), C.TEXT)
            p.setOnClickListener { e = s + m * 60000L; times() }
            drow.addView(p, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        box.add(drow, 6)

        val dlg = AlertDialog.Builder(this).setView(box).create()
        val brow = LinearLayout(this)
        brow.addW(btn("Cancel", Color.parseColor("#262932"), C.SUB) { dlg.dismiss() })
        brow.addW(btn("Save goal", C.ACCENT) {
            val t = title.text.toString().trim()
            if (t.isEmpty()) {
                Toast.makeText(this, "Enter a goal title", Toast.LENGTH_SHORT).show()
            } else if (e <= s) {
                Toast.makeText(this, "End time must be after start", Toast.LENGTH_SHORT).show()
            } else {
                val g = Goal(System.currentTimeMillis(), t, subjects[sel], s, e, false)
                Store.add(this, g)
                Scheduler.schedule(this, g)
                dlg.dismiss()
                refresh()
            }
        }, 10)
        box.add(brow, 20)
        dlg.show()
        dlg.window?.setBackgroundDrawable(shape(Color.TRANSPARENT, 24))
    }
}
