package com.jeefocus

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

object Perm {
    fun usage(c: Context): Boolean {
        val ops = c.getSystemService(AppOpsManager::class.java)
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }
    fun overlay(c: Context) = Settings.canDrawOverlays(c)
    fun exact(c: Context) =
        Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    fun notif(c: Context) =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}

class MainActivity : Activity() {
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.channels(this)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(24))
        }
        sv.addView(root)
        setContentView(sv)
        if (!Perm.notif(this)) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        try { startForegroundService(Intent(this, BlockerService::class.java)) } catch (_: Exception) {}
        refresh()
    }

    private fun tv(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { f() }
    }

    private fun pkgUri() = Uri.parse("package:$packageName")

    private fun refresh() {
        root.removeAllViews()
        root.addView(tv("JEE Focus", 30f, true))
        val act = Store.activeGoal(this)
        if (act != null) root.addView(tv("🔒 Locked until ${Store.hm(act.end)}: ${act.title}", 16f, true))

        if (!Perm.usage(this)) root.addView(btn("Grant Usage Access (required)") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        if (!Perm.overlay(this)) root.addView(btn("Grant Display Over Other Apps (required)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri())) })
        if (!Perm.exact(this)) root.addView(btn("Allow Exact Alarms") {
            if (Build.VERSION.SDK_INT >= 31)
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri())) })
        if (!Perm.notif(this)) root.addView(btn("Allow Notifications") {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) })

        root.addView(btn("Choose apps to block (${Store.blocked(this).size})") {
            startActivity(Intent(this, AppPickerActivity::class.java)) })
        root.addView(btn("+ Add goal") { addDialog() })
        root.addView(btn("Clear completed goals") {
            Store.goals(this).filter { it.done }.forEach { Scheduler.delete(this, it.id) }
            refresh()
        })

        val now = System.currentTimeMillis()
        val goals = Store.goals(this).sortedBy { it.start }
        if (goals.isEmpty()) root.addView(tv("No goals yet. Add one.", 16f))
        for (g in goals) {
            val status = when {
                g.done -> "✅ Done"
                now < g.start -> "⏰ Upcoming"
                now < g.end -> "🔥 In progress (apps locked)"
                else -> "⚠️ Overdue"
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(16), 0, dp(4))
            }
            card.addView(tv("${g.title}  [${g.subject}]", 18f, true))
            card.addView(tv("${Store.fmt(g.start)}  →  ${Store.fmt(g.end)}", 14f))
            card.addView(tv(status, 14f))
            val row = LinearLayout(this).apply { gravity = Gravity.START }
            if (!g.done) row.addView(btn("Done") { Scheduler.complete(this, g.id); refresh() })
            row.addView(btn("Delete") { Scheduler.delete(this, g.id); refresh() })
            card.addView(row)
            root.addView(card)
        }
    }

    private fun pick(cb: (Long) -> Unit) {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                val r = Calendar.getInstance()
                r.set(y, m, d, h, min, 0)
                r.set(Calendar.MILLISECOND, 0)
                cb(r.timeInMillis)
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun addDialog() {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), 0)
        }
        val title = EditText(this).apply { hint = "Goal (e.g. Rotational motion 30 Qs)" }
        val subj = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Physics", "Chemistry", "Maths", "Other"))
        }
        var s = 0L
        var e = 0L
        val sb = Button(this).apply { text = "Set start time" }
        val eb = Button(this).apply { text = "Set end time" }
        sb.setOnClickListener { pick { s = it; sb.text = "Start: ${Store.fmt(it)}" } }
        eb.setOnClickListener { pick { e = it; eb.text = "End: ${Store.fmt(it)}" } }
        l.addView(title); l.addView(subj); l.addView(sb); l.addView(eb)

        AlertDialog.Builder(this)
            .setTitle("New goal")
            .setView(l)
            .setPositiveButton("Save") { _, _ ->
                val t = title.text.toString().trim()
                if (t.isEmpty() || s == 0L || e == 0L || e <= s) {
                    Toast.makeText(this, "Enter title, start and an end after start", Toast.LENGTH_LONG).show()
                } else {
                    val g = Goal(System.currentTimeMillis(), t, subj.selectedItem.toString(), s, e, false)
                    Store.add(this, g)
                    Scheduler.schedule(this, g)
                    refresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
