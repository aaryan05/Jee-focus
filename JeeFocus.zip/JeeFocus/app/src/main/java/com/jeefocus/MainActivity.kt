package com.jeefocus

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.DatePickerDialog
import android.app.Dialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

object Perm {
    fun usage(c: Context): Boolean {
        val ops = c.getSystemService(AppOpsManager::class.java)
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }
    fun overlay(c: Context) = Settings.canDrawOverlays(c)
    fun exact(c: Context) =
        Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    fun notif(c: Context) =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private var intro = true
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 30000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars()
        Notifier.channels(this)
        val frame = FrameLayout(this)
        frame.background = bgGradient()
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(130))
        }
        sv.addView(list)
        frame.addView(sv, FrameLayout.LayoutParams(-1, -1))
        val fab = primary("+   New goal") { addDialog() }
        fab.background = gradBg(50)
        fab.setPadding(dp(28), dp(16), dp(28), dp(16))
        fab.elevation = dp(8).toFloat()
        frame.addView(fab, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            .apply { setMargins(0, 0, 0, dp(28)) })
        setContentView(frame)
        if (!Perm.notif(this)) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        try { startForegroundService(Intent(this, BlockerService::class.java)) } catch (_: Exception) {}
        intro = true
        h.removeCallbacks(tick)
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }

    private fun pkgUri() = Uri.parse("package:$packageName")

    private fun streak(all: List<Goal>, now: Long): Int {
        val days = all.filter { it.done }.map { dayIndex(it.start) }.toSet()
        var d = dayIndex(now)
        if (d !in days) d -= 1
        var n = 0
        while (d in days) { n++; d-- }
        return n
    }

    private fun refresh() {
        list.removeAllViews()
        val now = System.currentTimeMillis()
        val all = Store.goals(this)
        val animate = intro
        intro = false

        // header
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = when {
            hr < 5 -> "Still up?"
            hr < 12 -> "Good morning"
            hr < 17 -> "Good afternoon"
            hr < 22 -> "Good evening"
            else -> "Late night"
        }
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.mipmap.ic_launcher)
        head.addView(logo, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(14) })
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.addView(label(greet, 13f, C.SUB))
        tcol.addView(label("Let's focus.", 24f, C.TEXT, true))
        head.addView(tcol)
        list.add(head)

        // setup card
        val missing = ArrayList<Pair<String, () -> Unit>>()
        if (!Perm.usage(this)) missing.add("Allow Usage Access" to {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        if (!Perm.overlay(this)) missing.add("Allow Display Over Other Apps" to {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri())) })
        if (!Perm.exact(this)) missing.add("Allow Exact Alarms" to {
            if (Build.VERSION.SDK_INT >= 31)
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri())) })
        if (!Perm.notif(this)) missing.add("Allow Notifications" to {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) })
        if (missing.isNotEmpty()) {
            val pc = LinearLayout(this)
            pc.orientation = LinearLayout.VERTICAL
            pc.setPadding(dp(16), dp(16), dp(16), dp(16))
            pc.background = shape(Color.parseColor("#1FFFC145"), 20, Color.parseColor("#66FFC145"))
            pc.add(label("Finish setup", 16f, C.AMBER, true))
            pc.add(label("Locking and alerts won't work until these are allowed.", 13f, C.SUB), 2)
            for ((t, f) in missing) pc.add(btn(t, tint(C.AMBER), C.AMBER) { f() }, 10)
            list.add(pc, 18)
        }

        // ring
        val act = Store.activeGoal(this)
        val sod = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val today = all.filter { it.start >= sod && it.start < sod + 86400000L }
        val doneToday = today.count { it.done }

        val ring = RingView(this)
        val target: Float
        if (act != null) {
            ring.caption = "Focus mode"
            ring.big = leftText(act.end - now)
            ring.sub = "left  •  till ${Store.hm(act.end)}"
            target = (now - act.start).toFloat() / (act.end - act.start).toFloat()
        } else {
            ring.caption = "Today"
            ring.big = "$doneToday/${today.size}"
            ring.sub = if (today.isEmpty()) "no goals yet" else "goals done"
            target = if (today.isEmpty()) 0f else doneToday.toFloat() / today.size
        }
        if (animate) {
            ValueAnimator.ofFloat(0f, target).apply {
                duration = 1000
                interpolator = DecelerateInterpolator()
                addUpdateListener { ring.progress = it.animatedValue as Float }
                start()
            }
        } else {
            ring.progress = target
        }
        val rw = LinearLayout(this)
        rw.gravity = Gravity.CENTER
        rw.addView(ring, LinearLayout.LayoutParams(dp(250), dp(250)))
        list.add(rw, 22)

        if (act != null) {
            val t = label(act.title, 18f, C.TEXT, true)
            t.gravity = Gravity.CENTER
            list.add(t, 6)
            list.add(btn("Mark as done", tint(C.GREEN), C.GREEN) { Scheduler.complete(this, act.id); refresh() }, 14)
        } else {
            val next = all.filter { !it.done && it.start > now }.minByOrNull { it.start }
            val t = label(
                if (next != null) "Next: ${next.title}  •  ${whenText(next.start)}" else "Your apps are free right now.",
                14f, C.SUB)
            t.gravity = Gravity.CENTER
            list.add(t, 6)
        }

        // stats bar
        fun col(v: String, cap: String, click: (() -> Unit)?): LinearLayout {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.addView(label(v, 20f, C.TEXT, true))
            c.addView(label(cap, 11f, C.SUB))
            if (click != null) c.setOnClickListener { click() }
            return c
        }
        fun divider(): View = View(this).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) }
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(8), dp(14), dp(8), dp(14))
        bar.background = glass(20)
        bar.addW(col("${streak(all, now)}d", "Streak", null))
        bar.addView(divider(), LinearLayout.LayoutParams(dp(1), dp(30)))
        bar.addW(col("$doneToday/${today.size}", "Done today", null))
        bar.addView(divider(), LinearLayout.LayoutParams(dp(1), dp(30)))
        bar.addW(col("${Store.blocked(this).size}", "Blocked apps  >") {
            startActivity(Intent(this, AppPickerActivity::class.java)) })
        list.add(bar, 22)

        // goals
        fun section(title: String, gs: List<Goal>) {
            if (gs.isEmpty()) return
            list.add(caps(title), 28)
            for (g in gs) list.add(goalCard(g, now), 10)
        }
        section("Now", all.filter { !it.done && now >= it.start }.sortedBy { it.end })
        section("Up next", all.filter { !it.done && now < it.start }.sortedBy { it.start })
        section("Completed", all.filter { it.done }.sortedByDescending { it.start }.take(10))

        if (all.isEmpty()) {
            val e = LinearLayout(this)
            e.orientation = LinearLayout.VERTICAL
            e.setPadding(dp(18), dp(18), dp(18), dp(18))
            e.background = glass(20)
            e.add(label("Nothing planned yet", 16f, C.TEXT, true))
            e.add(label("Tap New goal, pick a subject and a time. Your distraction apps lock themselves when it starts.", 13f, C.SUB), 4)
            list.add(e, 28)
        } else {
            val hint = label("Tap the circle to complete. Hold a goal to delete.", 12f, C.SUB)
            hint.gravity = Gravity.CENTER
            list.add(hint, 24)
        }

        if (animate) {
            for (i in 0 until list.childCount) {
                val v = list.getChildAt(i)
                v.alpha = 0f
                v.translationY = dp(14).toFloat()
                v.animate().alpha(1f).translationY(0f).setStartDelay(i * 55L).setDuration(380).start()
            }
        }
    }

    private fun goalCard(g: Goal, now: Long): View {
        val col = subjectColor(g.subject)
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(14), dp(14), dp(14))
        row.background = glass(20)

        val strip = View(this)
        strip.background = shape(if (g.done) Color.parseColor("#55FFFFFF") else col, 4)
        row.addView(strip, LinearLayout.LayoutParams(dp(4), dp(58)).apply { rightMargin = dp(14) })

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.add(label("${g.subject.uppercase()}  •  ${leftText(g.end - g.start)}", 11f, col, true))
        val t = label(g.title, 17f, if (g.done) C.SUB else C.TEXT, true)
        if (g.done) t.paintFlags = t.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        mid.add(t, 4)
        mid.add(label("${whenText(g.start)}  →  ${Store.hm(g.end)}", 13f, C.SUB), 3)
        val (st, stc) = when {
            g.done -> "Completed" to C.GREEN
            now < g.start -> "Starts in ${leftText(g.start - now)}" to C.BLUE
            now < g.end -> "Locked now  •  ${leftText(g.end - now)} left" to C.AMBER
            else -> "Overdue by ${leftText(now - g.end)}" to C.RED
        }
        mid.add(label(st, 12f, stc, true), 6)
        row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))

        val ck = TextView(this)
        ck.text = if (g.done) "✓" else ""
        ck.gravity = Gravity.CENTER
        ck.textSize = 17f
        ck.setTextColor(Color.parseColor("#06210F"))
        ck.background = if (g.done) shape(C.GREEN, 50)
        else shape(Color.TRANSPARENT, 50, Color.parseColor("#66FFFFFF"))
        row.addView(ck, LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(10) })
        if (!g.done) ck.setOnClickListener { Scheduler.complete(this, g.id); refresh() }
        row.setOnLongClickListener { confirmDelete(g); true }
        return row
    }

    private fun confirmDelete(g: Goal) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Delete goal?")
            .setMessage(g.title)
            .setPositiveButton("Delete") { _, _ -> Scheduler.delete(this, g.id); refresh() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pick(cb: (Long) -> Unit) {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, hh, mm ->
                val r = Calendar.getInstance()
                r.set(y, m, d, hh, mm, 0)
                r.set(Calendar.MILLISECOND, 0)
                cb(r.timeInMillis)
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun chip(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 13f
        gravity = Gravity.CENTER
        typeface = medium()
        setPadding(dp(4), dp(10), dp(4), dp(10))
        isClickable = true
    }

    private fun addDialog() {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(12), dp(22), dp(24))
        val rr = dp(28).toFloat()
        box.background = GradientDrawable().apply {
            setColor(C.SHEET)
            cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f)
        }

        val handle = View(this)
        handle.background = shape(Color.parseColor("#33FFFFFF"), 4)
        box.addView(handle, LinearLayout.LayoutParams(dp(40), dp(4)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(18)
        })

        box.add(caps("New goal"))
        val title = EditText(this)
        title.hint = "What will you finish?"
        title.setHintTextColor(Color.parseColor("#66FFFFFF"))
        title.setTextColor(C.TEXT)
        title.textSize = 22f
        title.typeface = medium()
        title.setSingleLine(true)
        title.background = null
        title.setPadding(0, dp(10), 0, dp(10))
        box.add(title, 6)
        box.addView(View(this).apply { setBackgroundColor(Color.parseColor("#26FFFFFF")) },
            LinearLayout.LayoutParams(-1, dp(1)))

        box.add(caps("Subject"), 20)
        val values = listOf("Physics", "Chemistry", "Maths", "Other")
        val names = listOf("Physics", "Chem", "Maths", "Other")
        var sel = 0
        val chips = names.map { chip(it) }
        fun paint() {
            chips.forEachIndexed { i, p ->
                val c = subjectColor(values[i])
                if (i == sel) { p.background = shape(c, 14); p.setTextColor(Color.parseColor("#101010")) }
                else { p.background = shape(tint(c), 14); p.setTextColor(c) }
            }
        }
        val crow = LinearLayout(this)
        chips.forEachIndexed { i, p ->
            p.setOnClickListener { sel = i; paint() }
            crow.addView(p, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = dp(8) })
        }
        paint()
        box.add(crow, 8)

        var s = System.currentTimeMillis() / 60000 * 60000
        var e = s + 3600000L
        fun tile(cap: String): Pair<LinearLayout, TextView> {
            val t = LinearLayout(this)
            t.orientation = LinearLayout.VERTICAL
            t.setPadding(dp(14), dp(12), dp(14), dp(12))
            t.background = glass(16)
            t.addView(caps(cap))
            val v = label("", 15f, C.TEXT, true)
            t.addView(v, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
            return t to v
        }
        val (sTile, sVal) = tile("Starts")
        val (eTile, eVal) = tile("Ends")
        fun times() {
            sVal.text = whenText(s)
            eVal.text = whenText(e)
        }
        times()
        sTile.setOnClickListener { pick { s = it; if (e <= s) e = s + 3600000L; times() } }
        eTile.setOnClickListener { pick { e = it; times() } }
        val trow = LinearLayout(this)
        trow.addW(sTile)
        trow.addW(eTile, 10)
        box.add(trow, 20)

        box.add(caps("Quick duration"), 20)
        val drow = LinearLayout(this)
        listOf("30 min" to 30, "1 hr" to 60, "2 hr" to 120, "3 hr" to 180).forEachIndexed { i, (t, m) ->
            val p = chip(t)
            p.background = shape(C.CHIP, 14)
            p.setTextColor(C.TEXT)
            p.setOnClickListener { e = s + m * 60000L; times() }
            drow.addView(p, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = dp(8) })
        }
        box.add(drow, 8)

        box.add(primary("Create goal") {
            val t = title.text.toString().trim()
            if (t.isEmpty()) {
                Toast.makeText(this, "Give your goal a name", Toast.LENGTH_SHORT).show()
            } else if (e <= s) {
                Toast.makeText(this, "End time must be after start", Toast.LENGTH_SHORT).show()
            } else {
                val g = Goal(System.currentTimeMillis(), t, values[sel], s, e, false)
                Store.add(this, g)
                Scheduler.schedule(this, g)
                dlg.dismiss()
                intro = true
                refresh()
            }
        }, 26)

        dlg.setContentView(box)
        dlg.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout(-1, -2)
            w.setGravity(Gravity.BOTTOM)
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }
        dlg.show()
    }
}
