package com.jeefocus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build

object Notifier {
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("goals", "Goal reminders", NotificationManager.IMPORTANCE_HIGH))
        val od = NotificationChannel("overdue", "Overdue alerts", NotificationManager.IMPORTANCE_HIGH)
        od.enableVibration(true)
        od.vibrationPattern = longArrayOf(0, 600, 300, 600, 300, 900)
        od.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
        )
        nm.createNotificationChannel(od)
        nm.createNotificationChannel(
            NotificationChannel("service", "Focus protection", NotificationManager.IMPORTANCE_MIN))
    }

    fun post(c: Context, g: Goal, channel: String, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) return
        channels(c)
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val done = Scheduler.pending(c, g.id, 3, "DONE")
        val n = Notification.Builder(c, channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(false)
            .addAction(Notification.Action.Builder(null, "Mark done", done).build())
            .build()
        c.getSystemService(NotificationManager::class.java).notify(Scheduler.nid(g.id), n)
    }
}

class GoalReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", 0L)
        val g = Store.find(c, id) ?: return
        if (i.action == "DONE") {
            Scheduler.complete(c, id)
            return
        }
        if (g.done) return
        val now = System.currentTimeMillis()
        when (i.action) {
            "START" -> Notifier.post(c, g, "goals", "Focus time: ${g.title}",
                "${g.subject}. Distraction apps are locked until ${Store.hm(g.end)}.")
            "END" -> {
                Notifier.post(c, g, "overdue", "Time's up: ${g.title}",
                    "Goal time ended. Mark it done if finished, or keep going.")
                Scheduler.setAlarm(c, g.id, 2, "OVERDUE", now + 5 * 60000)
            }
            "OVERDUE" -> {
                val over = ((now - g.end) / 60000).toInt()
                if (over > Scheduler.OVERDUE_CAP_MIN) return
                Notifier.post(c, g, "overdue", "$over min overdue: ${g.title}",
                    "You are past your end time. Finish it and mark done.")
                val gap = if (over < 15) 5 else 2
                Scheduler.setAlarm(c, g.id, 2, "OVERDUE", now + gap * 60000L)
            }
        }
    }
}
