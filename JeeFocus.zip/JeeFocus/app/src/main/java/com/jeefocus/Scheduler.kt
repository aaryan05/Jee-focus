package com.jeefocus

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

// kinds: 0 = START, 1 = END, 2 = OVERDUE, 3 = DONE action
object Scheduler {
    const val OVERDUE_CAP_MIN = 180

    fun nid(id: Long): Int = (id % 100000000L).toInt()
    private fun code(id: Long, kind: Int) = nid(id) * 4 + kind

    fun pending(c: Context, id: Long, kind: Int, action: String): PendingIntent =
        PendingIntent.getBroadcast(
            c, code(id, kind),
            Intent(c, GoalReceiver::class.java).setAction(action).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun setAlarm(c: Context, id: Long, kind: Int, action: String, at: Long) {
        if (at <= System.currentTimeMillis()) return
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = pending(c, id, kind, action)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.set(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun schedule(c: Context, g: Goal) {
        setAlarm(c, g.id, 0, "START", g.start)
        setAlarm(c, g.id, 1, "END", g.end)
    }

    fun cancel(c: Context, id: Long) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(pending(c, id, 0, "START"))
        am.cancel(pending(c, id, 1, "END"))
        am.cancel(pending(c, id, 2, "OVERDUE"))
        c.getSystemService(NotificationManager::class.java).cancel(nid(id))
    }

    fun complete(c: Context, id: Long) {
        Store.setDone(c, id)
        cancel(c, id)
    }

    fun delete(c: Context, id: Long) {
        cancel(c, id)
        Store.remove(c, id)
    }

    fun rescheduleAll(c: Context) {
        val now = System.currentTimeMillis()
        Store.goals(c).filter { !it.done }.forEach { g ->
            schedule(c, g)
            if (g.end <= now && now - g.end < OVERDUE_CAP_MIN * 60000L) {
                setAlarm(c, g.id, 2, "OVERDUE", now + 60000)
            }
        }
    }
}
