package com.jeefocus

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout

class BlockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars()
        build()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        build()
    }

    private fun build() {
        val g = Store.activeGoal(this)
        if (g == null) { finish(); return }
        val now = System.currentTimeMillis()
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER
        l.background = bgGradient()
        l.setPadding(dp(28), dp(28), dp(28), dp(28))

        val ring = RingView(this)
        ring.caption = "Locked"
        ring.big = leftText(g.end - now)
        ring.sub = "left  •  till ${Store.hm(g.end)}"
        ring.progress = (now - g.start).toFloat() / (g.end - g.start).toFloat()
        l.addView(ring, LinearLayout.LayoutParams(dp(250), dp(250)))

        val t = label(g.title, 22f, C.TEXT, true)
        t.gravity = Gravity.CENTER
        l.add(t, 22)
        val sub = label(g.subject, 14f, subjectColor(g.subject), true)
        sub.gravity = Gravity.CENTER
        l.add(sub, 4)
        val quote = listOf(
            "Phone down. Pen up.",
            "One more question. Then one more.",
            "Future you is counting on this hour.",
            "Discipline beats motivation.",
            "This is the hour that decides your rank."
        ).random()
        val q = label(quote, 15f, C.SUB)
        q.gravity = Gravity.CENTER
        l.add(q, 16)

        l.add(primary("Back to work") { home() }, 36)
        l.add(btn("I finished this goal", C.CHIP, C.SUB) {
            Scheduler.complete(this, g.id); home()
        }, 12)
        setContentView(l)
    }

    private fun home() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = home()
}
