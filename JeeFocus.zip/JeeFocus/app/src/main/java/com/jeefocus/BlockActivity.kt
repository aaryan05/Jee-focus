package com.jeefocus

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout

class BlockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        styleBars()
        build()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        build()
    }

    private fun build() {
        val g = Store.activeGoal(this)
        if (g == null) { finish(); return }
        val now = System.currentTimeMillis()
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER
        l.setPadding(dp(28), dp(28), dp(28), dp(28))
        l.setBackgroundColor(C.BG)

        val ring = label("LOCKED", 13f, C.ORANGE, true)
        ring.gravity = Gravity.CENTER
        ring.setPadding(dp(18), dp(8), dp(18), dp(8))
        ring.background = shape(tint(C.ORANGE), 50)
        l.addView(ring, LinearLayout.LayoutParams(-2, -2))

        val t = label("Focus time", 32f, C.TEXT, true)
        t.gravity = Gravity.CENTER
        l.add(t, 24)
        val goal = label(g.title, 20f, C.TEXT)
        goal.gravity = Gravity.CENTER
        l.add(goal, 10)
        val sub = label("${g.subject}  •  ${leftText(g.end - now)} left", 15f, C.SUB)
        sub.gravity = Gravity.CENTER
        l.add(sub, 6)
        val msg = label("This app is locked until your goal ends. Get back to work.", 14f, C.SUB)
        msg.gravity = Gravity.CENTER
        l.add(msg, 18)

        l.add(btn("Go to home", C.ACCENT) { home() }, 32)
        l.add(btn("I finished this goal", Color.parseColor("#262932"), C.SUB) {
            Scheduler.complete(this, g.id); home()
        }, 12)
        setContentView(l)
    }

    private fun home() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = home()
}
