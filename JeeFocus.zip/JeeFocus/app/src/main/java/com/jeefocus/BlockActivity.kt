package com.jeefocus

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        build()
    }

    private fun tv(t: String, size: Float): TextView = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun build() {
        val g = Store.activeGoal(this)
        if (g == null) { finish(); return }
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
            setBackgroundColor(Color.parseColor("#0B0B0F"))
        }
        l.addView(tv("🔒", 56f))
        l.addView(tv("Focus time", 28f))
        l.addView(tv(g.title, 20f))
        l.addView(tv("${g.subject} until ${Store.hm(g.end)}", 16f))
        l.addView(tv("This app is locked. Get back to work.", 14f))
        l.addView(Button(this).apply {
            text = "Go to home"
            setOnClickListener { home() }
        })
        l.addView(Button(this).apply {
            text = "I finished this goal"
            setOnClickListener { Scheduler.complete(this@BlockActivity, g.id); home() }
        })
        setContentView(l)
    }

    private fun home() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = home()
}
