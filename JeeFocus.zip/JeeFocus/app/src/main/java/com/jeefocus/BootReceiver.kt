package com.jeefocus

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.rescheduleAll(c)
        try { c.startForegroundService(Intent(c, BlockerService::class.java)) } catch (_: Exception) {}
    }
}
